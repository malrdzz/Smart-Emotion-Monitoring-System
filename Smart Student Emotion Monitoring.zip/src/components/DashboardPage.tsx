import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, Heart, Lightbulb, Calendar } from 'lucide-react';

export function DashboardPage() {
  // Mock data for emotion trends over time
  const emotionTrendsDaily = [
    { date: 'Mon', joy: 65, sadness: 20, anger: 10, anxiety: 25, love: 50 },
    { date: 'Tue', joy: 70, sadness: 15, anger: 5, anxiety: 20, love: 55 },
    { date: 'Wed', joy: 45, sadness: 40, anger: 15, anxiety: 50, love: 30 },
    { date: 'Thu', joy: 55, sadness: 30, anger: 10, anxiety: 35, love: 40 },
    { date: 'Fri', joy: 80, sadness: 10, anger: 5, anxiety: 15, love: 70 },
    { date: 'Sat', joy: 90, sadness: 5, anger: 0, anxiety: 10, love: 85 },
    { date: 'Sun', joy: 75, sadness: 15, anger: 5, anxiety: 20, love: 60 },
  ];

  const emotionTrendsWeekly = [
    { date: 'Week 1', joy: 60, sadness: 25, anger: 10, anxiety: 30, love: 45 },
    { date: 'Week 2', joy: 65, sadness: 20, anger: 8, anxiety: 25, love: 55 },
    { date: 'Week 3', joy: 70, sadness: 18, anger: 12, anxiety: 28, love: 60 },
    { date: 'Week 4', joy: 75, sadness: 15, anger: 7, anxiety: 20, love: 65 },
  ];

  // Mock data for emotion distribution
  const emotionDistribution = [
    { name: 'Joy', value: 35, color: '#86efac' },
    { name: 'Sadness', value: 15, color: '#60a5fa' },
    { name: 'Anger', value: 8, color: '#f87171' },
    { name: 'Anxiety', value: 22, color: '#fbbf24' },
    { name: 'Love', value: 20, color: '#a78bfa' },
  ];

  // Mock timeline data
  const emotionTimeline = [
    { date: 'Oct 19, 2025', time: '10:30 AM', emotion: 'Joy', emoji: '😊', sentiment: 'Positive' },
    { date: 'Oct 18, 2025', time: '3:45 PM', emotion: 'Anxiety', emoji: '😰', sentiment: 'Negative' },
    { date: 'Oct 18, 2025', time: '9:00 AM', emotion: 'Love', emoji: '❤️', sentiment: 'Positive' },
    { date: 'Oct 17, 2025', time: '5:20 PM', emotion: 'Joy', emoji: '😄', sentiment: 'Positive' },
    { date: 'Oct 17, 2025', time: '11:15 AM', emotion: 'Sadness', emoji: '😢', sentiment: 'Negative' },
    { date: 'Oct 16, 2025', time: '2:30 PM', emotion: 'Joy', emoji: '😊', sentiment: 'Positive' },
  ];

  const motivationalQuotes = [
    "You're doing better than you think. Keep tracking your emotions - every step counts! 💪",
    "Your emotional awareness is growing. This week shows great progress in managing your feelings. 🌟",
    "Remember: It's okay to have difficult emotions. What matters is how you understand and process them. 🌈",
  ];

  const currentQuote = motivationalQuotes[0];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl mb-2">Emotion Dashboard</h1>
          <p className="text-muted-foreground">
            Visualize and understand your emotional patterns
          </p>
        </div>

        {/* Summary Cards */}
        <div className="grid md:grid-cols-3 gap-6">
          <Card className="shadow-lg border-2 border-primary/20">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm">Average Sentiment</CardTitle>
              <TrendingUp className="w-4 h-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl">7.2/10</div>
              <p className="text-xs text-muted-foreground mt-1">
                <span className="text-green-600">↑ 12%</span> from last week
              </p>
            </CardContent>
          </Card>

          <Card className="shadow-lg border-2 border-secondary/40">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm">Most Frequent Emotion</CardTitle>
              <Heart className="w-4 h-4 text-secondary" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl flex items-center gap-2">
                😊 Joy
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Detected 45 times this week
              </p>
            </CardContent>
          </Card>

          <Card className="shadow-lg border-2 border-purple-200">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm">Check-ins</CardTitle>
              <Calendar className="w-4 h-4 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl">28</div>
              <p className="text-xs text-muted-foreground mt-1">
                This month
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Motivational Quote */}
        <Card className="shadow-lg bg-gradient-to-r from-primary/10 to-secondary/10 border-2 border-primary/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Lightbulb className="w-5 h-5 text-primary" />
              AI-Generated Insight
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-lg">{currentQuote}</p>
          </CardContent>
        </Card>

        {/* Emotion Trends Chart */}
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>Emotion Trends Over Time</CardTitle>
            <CardDescription>Track how your emotions change throughout the week</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="daily" className="w-full">
              <TabsList className="mb-4">
                <TabsTrigger value="daily">Daily</TabsTrigger>
                <TabsTrigger value="weekly">Weekly</TabsTrigger>
                <TabsTrigger value="monthly">Monthly</TabsTrigger>
              </TabsList>
              
              <TabsContent value="daily">
                <ResponsiveContainer width="100%" height={350}>
                  <LineChart data={emotionTrendsDaily}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e0f2fe" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="joy" stroke="#86efac" strokeWidth={2} name="Joy" />
                    <Line type="monotone" dataKey="sadness" stroke="#60a5fa" strokeWidth={2} name="Sadness" />
                    <Line type="monotone" dataKey="anger" stroke="#f87171" strokeWidth={2} name="Anger" />
                    <Line type="monotone" dataKey="anxiety" stroke="#fbbf24" strokeWidth={2} name="Anxiety" />
                    <Line type="monotone" dataKey="love" stroke="#a78bfa" strokeWidth={2} name="Love" />
                  </LineChart>
                </ResponsiveContainer>
              </TabsContent>
              
              <TabsContent value="weekly">
                <ResponsiveContainer width="100%" height={350}>
                  <LineChart data={emotionTrendsWeekly}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e0f2fe" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="joy" stroke="#86efac" strokeWidth={2} name="Joy" />
                    <Line type="monotone" dataKey="sadness" stroke="#60a5fa" strokeWidth={2} name="Sadness" />
                    <Line type="monotone" dataKey="anger" stroke="#f87171" strokeWidth={2} name="Anger" />
                    <Line type="monotone" dataKey="anxiety" stroke="#fbbf24" strokeWidth={2} name="Anxiety" />
                    <Line type="monotone" dataKey="love" stroke="#a78bfa" strokeWidth={2} name="Love" />
                  </LineChart>
                </ResponsiveContainer>
              </TabsContent>
              
              <TabsContent value="monthly">
                <ResponsiveContainer width="100%" height={350}>
                  <LineChart data={emotionTrendsWeekly}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e0f2fe" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="joy" stroke="#86efac" strokeWidth={2} name="Joy" />
                    <Line type="monotone" dataKey="sadness" stroke="#60a5fa" strokeWidth={2} name="Sadness" />
                    <Line type="monotone" dataKey="anger" stroke="#f87171" strokeWidth={2} name="Anger" />
                    <Line type="monotone" dataKey="anxiety" stroke="#fbbf24" strokeWidth={2} name="Anxiety" />
                    <Line type="monotone" dataKey="love" stroke="#a78bfa" strokeWidth={2} name="Love" />
                  </LineChart>
                </ResponsiveContainer>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Emotion Distribution */}
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle>Emotion Distribution</CardTitle>
              <CardDescription>Proportion of emotions detected this week</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={emotionDistribution}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {emotionDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Bar Chart */}
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle>Weekly Emotion Summary</CardTitle>
              <CardDescription>Total emotion occurrences</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={emotionDistribution}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e0f2fe" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="value" radius={[8, 8, 0, 0]}>
                    {emotionDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Emotion Timeline */}
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>Recent Emotion Timeline</CardTitle>
            <CardDescription>Your latest emotional check-ins</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {emotionTimeline.map((entry, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-4 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <div className="text-3xl">{entry.emoji}</div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span>{entry.emotion}</span>
                        <Badge
                          variant={entry.sentiment === 'Positive' ? 'default' : 'destructive'}
                          className="text-xs"
                        >
                          {entry.sentiment}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {entry.date} at {entry.time}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
