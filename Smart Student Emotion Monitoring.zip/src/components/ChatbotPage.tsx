import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Slider } from './ui/slider';
import { Send, Bot, User as UserIcon } from 'lucide-react';
import { ScrollArea } from './ui/scroll-area';

interface Message {
  id: string;
  type: 'user' | 'bot';
  content: string;
  emotion?: string;
  sentiment?: string;
  timestamp: Date;
}

export function ChatbotPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'bot',
      content: "Hi! I'm here to help you track and understand your emotions. How are you feeling today?",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [emotionIntensity, setEmotionIntensity] = useState([50]);

  const emotions = [
    { emoji: '😊', label: 'Happy' },
    { emoji: '😢', label: 'Sad' },
    { emoji: '😡', label: 'Angry' },
    { emoji: '😱', label: 'Anxious' },
    { emoji: '🤔', label: 'Thoughtful' },
    { emoji: '❤️', label: 'Loved' },
  ];

  const detectEmotion = (text: string): { emotion: string; sentiment: string } => {
    const lowerText = text.toLowerCase();
    
    if (lowerText.includes('happy') || lowerText.includes('great') || lowerText.includes('good') || lowerText.includes('excited')) {
      return { emotion: 'Joy', sentiment: 'Positive' };
    } else if (lowerText.includes('sad') || lowerText.includes('depressed') || lowerText.includes('down')) {
      return { emotion: 'Sadness', sentiment: 'Negative' };
    } else if (lowerText.includes('angry') || lowerText.includes('mad') || lowerText.includes('frustrated')) {
      return { emotion: 'Anger', sentiment: 'Negative' };
    } else if (lowerText.includes('anxious') || lowerText.includes('worried') || lowerText.includes('stressed') || lowerText.includes('nervous')) {
      return { emotion: 'Anxiety', sentiment: 'Negative' };
    } else if (lowerText.includes('love') || lowerText.includes('care') || lowerText.includes('grateful')) {
      return { emotion: 'Love', sentiment: 'Positive' };
    } else if (lowerText.includes('confused') || lowerText.includes('uncertain')) {
      return { emotion: 'Confusion', sentiment: 'Neutral' };
    } else {
      return { emotion: 'Neutral', sentiment: 'Neutral' };
    }
  };

  const generateResponse = (emotion: string, sentiment: string): string => {
    const responses: Record<string, string[]> = {
      Joy: [
        "That's wonderful to hear! It's great that you're experiencing positive emotions. What's making you feel this way?",
        "I'm so glad you're feeling happy! Remember to cherish these moments and reflect on what brings you joy.",
      ],
      Sadness: [
        "I hear you, and I'm sorry you're feeling this way. Remember, it's okay to feel sad sometimes. Would you like to talk more about what's troubling you?",
        "Your feelings are valid. Sadness is a natural emotion. I'm here to listen and support you through this.",
      ],
      Anger: [
        "It sounds like you're going through a tough time. Anger is a normal emotion. Have you thought about what might help you process these feelings?",
        "I understand you're feeling frustrated. Let's work through this together. What triggered these feelings?",
      ],
      Anxiety: [
        "Anxiety can be overwhelming. Remember to take deep breaths. You're not alone in this. What's been on your mind?",
        "I can sense your worry. It's important to acknowledge these feelings. Have you tried any relaxation techniques?",
      ],
      Love: [
        "What a beautiful emotion to experience! Feeling connected and grateful is so important for well-being.",
        "That's lovely! Positive emotions like love and gratitude can really brighten our days.",
      ],
      Neutral: [
        "Thank you for sharing with me. Tell me more about what's on your mind today.",
        "I'm here to listen. How has your day been so far?",
      ],
    };

    const emotionResponses = responses[emotion] || responses.Neutral;
    return emotionResponses[Math.floor(Math.random() * emotionResponses.length)];
  };

  const handleSend = () => {
    if (!input.trim()) return;

    const { emotion, sentiment } = detectEmotion(input);
    
    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: input,
      emotion,
      sentiment,
      timestamp: new Date(),
    };

    const botResponse: Message = {
      id: (Date.now() + 1).toString(),
      type: 'bot',
      content: generateResponse(emotion, sentiment),
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage, botResponse]);
    setInput('');
  };

  const handleEmotionClick = (emoji: string, label: string) => {
    setInput((prev) => prev + ` ${emoji}`);
  };

  const getIntensityEmoji = () => {
    const value = emotionIntensity[0];
    if (value < 20) return '😢';
    if (value < 40) return '😔';
    if (value < 60) return '😐';
    if (value < 80) return '🙂';
    return '😄';
  };

  const getIntensityColor = () => {
    const value = emotionIntensity[0];
    if (value < 33) return 'from-red-500 to-orange-500';
    if (value < 67) return 'from-orange-500 to-yellow-500';
    return 'from-yellow-500 to-green-500';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-6">
          <h1 className="text-3xl mb-2">Chat with Your Emotion Assistant</h1>
          <p className="text-muted-foreground">
            Share your feelings and get personalized support
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Chat Area */}
          <Card className="lg:col-span-2 shadow-lg">
            <CardHeader className="border-b bg-gradient-to-r from-primary/10 to-secondary/10">
              <CardTitle className="flex items-center gap-2">
                <Bot className="w-5 h-5 text-primary" />
                Emotion Chat Assistant
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <ScrollArea className="h-[500px] p-6">
                <div className="space-y-4">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex gap-3 ${
                        message.type === 'user' ? 'flex-row-reverse' : 'flex-row'
                      }`}
                    >
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                          message.type === 'bot'
                            ? 'bg-primary text-primary-foreground'
                            : 'bg-secondary text-secondary-foreground'
                        }`}
                      >
                        {message.type === 'bot' ? (
                          <Bot className="w-4 h-4" />
                        ) : (
                          <UserIcon className="w-4 h-4" />
                        )}
                      </div>
                      <div
                        className={`flex flex-col gap-1 max-w-[70%] ${
                          message.type === 'user' ? 'items-end' : 'items-start'
                        }`}
                      >
                        <div
                          className={`rounded-2xl px-4 py-2 ${
                            message.type === 'bot'
                              ? 'bg-muted'
                              : 'bg-primary text-primary-foreground'
                          }`}
                        >
                          <p>{message.content}</p>
                        </div>
                        {message.emotion && message.sentiment && (
                          <div className="flex gap-2">
                            <Badge variant="secondary" className="text-xs">
                              Detected: {message.emotion}
                            </Badge>
                            <Badge
                              variant={
                                message.sentiment === 'Positive'
                                  ? 'default'
                                  : message.sentiment === 'Negative'
                                  ? 'destructive'
                                  : 'outline'
                              }
                              className="text-xs"
                            >
                              {message.sentiment}
                            </Badge>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>

              {/* Input Area */}
              <div className="p-6 border-t bg-muted/30 space-y-4">
                {/* Emotion Quick Select */}
                <div className="flex gap-2 flex-wrap">
                  {emotions.map((emotion) => (
                    <button
                      key={emotion.label}
                      onClick={() => handleEmotionClick(emotion.emoji, emotion.label)}
                      className="text-2xl hover:scale-125 transition-transform"
                      title={emotion.label}
                    >
                      {emotion.emoji}
                    </button>
                  ))}
                </div>

                {/* Emotion Intensity Slider */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-sm text-muted-foreground">
                      Emotion Intensity
                    </label>
                    <span className="text-2xl">{getIntensityEmoji()}</span>
                  </div>
                  <div className="relative">
                    <div className={`absolute inset-0 rounded-full bg-gradient-to-r ${getIntensityColor()} opacity-30`}></div>
                    <Slider
                      value={emotionIntensity}
                      onValueChange={setEmotionIntensity}
                      max={100}
                      step={1}
                      className="relative"
                    />
                  </div>
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>😢 Very Sad</span>
                    <span>😄 Very Happy</span>
                  </div>
                </div>

                {/* Text Input */}
                <div className="flex gap-2">
                  <Input
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                    placeholder="Type your feelings here..."
                    className="flex-1 bg-white"
                  />
                  <Button onClick={handleSend} className="gap-2">
                    <Send className="w-4 h-4" />
                    Send
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Tips Panel */}
          <Card className="shadow-lg">
            <CardHeader className="bg-gradient-to-br from-secondary/20 to-primary/10">
              <CardTitle>Emotion Tracking Tips</CardTitle>
            </CardHeader>
            <CardContent className="pt-6 space-y-4">
              <div className="space-y-2">
                <h4>💬 Be Honest</h4>
                <p className="text-sm text-muted-foreground">
                  Express your true feelings without judgment. This is a safe space.
                </p>
              </div>
              <div className="space-y-2">
                <h4>📝 Journal Daily</h4>
                <p className="text-sm text-muted-foreground">
                  Regular check-ins help identify patterns in your emotional well-being.
                </p>
              </div>
              <div className="space-y-2">
                <h4>🎯 Use Specifics</h4>
                <p className="text-sm text-muted-foreground">
                  Describe what triggered your emotions for better insights.
                </p>
              </div>
              <div className="space-y-2">
                <h4>📊 Track Progress</h4>
                <p className="text-sm text-muted-foreground">
                  Visit the Dashboard to see your emotional trends over time.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
