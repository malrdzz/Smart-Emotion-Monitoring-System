import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Switch } from './ui/switch';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { User, Mail, GraduationCap, Shield, Download, Trash2 } from 'lucide-react';

export function ProfilePage() {
  const userInfo = {
    name: 'Alex Johnson',
    email: 'alex.johnson@university.edu',
    university: 'State University',
    memberSince: 'January 2025',
    totalCheckIns: 156,
  };

  const emotionHistory = [
    {
      date: 'Oct 19, 2025',
      emotion: 'Joy',
      emoji: '😊',
      sentiment: 'Positive',
      notes: 'Had a great day with friends',
    },
    {
      date: 'Oct 18, 2025',
      emotion: 'Anxiety',
      emoji: '😰',
      sentiment: 'Negative',
      notes: 'Worried about upcoming exam',
    },
    {
      date: 'Oct 18, 2025',
      emotion: 'Love',
      emoji: '❤️',
      sentiment: 'Positive',
      notes: 'Feeling grateful for family support',
    },
    {
      date: 'Oct 17, 2025',
      emotion: 'Joy',
      emoji: '😄',
      sentiment: 'Positive',
      notes: 'Completed project successfully',
    },
    {
      date: 'Oct 17, 2025',
      emotion: 'Sadness',
      emoji: '😢',
      sentiment: 'Negative',
      notes: 'Missing home',
    },
    {
      date: 'Oct 16, 2025',
      emotion: 'Joy',
      emoji: '😊',
      sentiment: 'Positive',
      notes: 'Good study session',
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 p-4 md:p-8">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl mb-2">Profile & Settings</h1>
          <p className="text-muted-foreground">
            Manage your personal information and privacy settings
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Profile Info */}
          <Card className="shadow-lg lg:col-span-1">
            <CardHeader className="text-center pb-4">
              <div className="flex justify-center mb-4">
                <Avatar className="w-24 h-24 border-4 border-primary/20">
                  <AvatarImage src="https://images.unsplash.com/photo-1742093162117-7c4e94df7cb5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHVkZW50JTIwc3R1ZHlpbmclMjBjYWxtJTIwcGVhY2VmdWx8ZW58MXx8fHwxNzYwODkxNzk3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral" />
                  <AvatarFallback>AJ</AvatarFallback>
                </Avatar>
              </div>
              <CardTitle>{userInfo.name}</CardTitle>
              <CardDescription>Student</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex items-center gap-3 text-sm">
                  <Mail className="w-4 h-4 text-muted-foreground" />
                  <span>{userInfo.email}</span>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  <GraduationCap className="w-4 h-4 text-muted-foreground" />
                  <span>{userInfo.university}</span>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  <User className="w-4 h-4 text-muted-foreground" />
                  <span>Member since {userInfo.memberSince}</span>
                </div>
              </div>

              <div className="pt-4 border-t">
                <div className="text-center">
                  <div className="text-3xl mb-1">{userInfo.totalCheckIns}</div>
                  <p className="text-sm text-muted-foreground">Total Check-ins</p>
                </div>
              </div>

              <Button variant="outline" className="w-full">
                Edit Profile
              </Button>
            </CardContent>
          </Card>

          {/* Privacy & Settings */}
          <Card className="shadow-lg lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-primary" />
                Privacy & Data Control
              </CardTitle>
              <CardDescription>
                Manage how your emotional data is stored and used
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                  <div className="flex-1">
                    <h4>Data Encryption</h4>
                    <p className="text-sm text-muted-foreground">
                      All your emotional data is encrypted end-to-end
                    </p>
                  </div>
                  <Switch defaultChecked disabled />
                </div>

                <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                  <div className="flex-1">
                    <h4>AI Analysis</h4>
                    <p className="text-sm text-muted-foreground">
                      Allow AI to analyze your emotions and provide insights
                    </p>
                  </div>
                  <Switch defaultChecked />
                </div>

                <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                  <div className="flex-1">
                    <h4>Motivational Messages</h4>
                    <p className="text-sm text-muted-foreground">
                      Receive AI-generated motivational support
                    </p>
                  </div>
                  <Switch defaultChecked />
                </div>

                <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                  <div className="flex-1">
                    <h4>Email Notifications</h4>
                    <p className="text-sm text-muted-foreground">
                      Get weekly emotion summary reports
                    </p>
                  </div>
                  <Switch />
                </div>
              </div>

              <div className="pt-4 border-t space-y-3">
                <h4>Data Management</h4>
                <div className="flex gap-3">
                  <Button variant="outline" className="gap-2">
                    <Download className="w-4 h-4" />
                    Export My Data
                  </Button>
                  <Button variant="destructive" className="gap-2">
                    <Trash2 className="w-4 h-4" />
                    Delete All Data
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  You can export or permanently delete all your emotional data at any time.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Emotion History Table */}
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>Emotion History</CardTitle>
            <CardDescription>
              Complete log of your emotional check-ins
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="rounded-lg border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Emotion</TableHead>
                    <TableHead>Sentiment</TableHead>
                    <TableHead>Notes</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {emotionHistory.map((entry, index) => (
                    <TableRow key={index}>
                      <TableCell>{entry.date}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <span className="text-xl">{entry.emoji}</span>
                          <span>{entry.emotion}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            entry.sentiment === 'Positive' ? 'default' : 'destructive'
                          }
                        >
                          {entry.sentiment}
                        </Badge>
                      </TableCell>
                      <TableCell className="max-w-xs truncate">
                        {entry.notes}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
