
  # Smart Student Emotion Monitoring

  This is a code bundle for Smart Student Emotion Monitoring. The original project is available at https://www.figma.com/design/P4CTmrGL39ZkJdGNXZ7aOW/Smart-Student-Emotion-Monitoring.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  